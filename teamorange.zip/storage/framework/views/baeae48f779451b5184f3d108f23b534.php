<?php $__env->startPush('styles'); ?>
     <link rel="stylesheet" href="<?php echo e(asset('web/css/vendoor/contact.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
  <body>
    
  <?php echo $__env->make('components.web-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="banner sm" data-aos="fade-up" data-aos-duration="3000" data-aos-delay="500">
      <img class="w-100" src="<?php echo e(asset('web/images/banner/contact.png')); ?>" alt="">
      <div class="container banner-content" >
          <div class="row">
              <div class="col-md-7" data-aos="fade-up" data-aos-duration="3000" data-aos-delay="1000">
                  <h1>Contact us</h1>
              </div>
          </div>
      </div>
    </section>
      <section class="banner-bottom">
        <div class="container" data-aos="fade-up" data-aos-duration="3000" data-aos-delay="2000">
            <ul class="d-flex">
                <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
                <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
            </ul>
        </div>
      </section>
      <div class="section contact">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h4 class="title" data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-aos-duration="500">Drop us message</h4>
                    <p data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-aos-duration="900">Praising pain was born and I will give you a complete account of the system, and</p>

                    <form action="<?php echo e(url('contact-save')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 mb-4" data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-aos-duration="1000">
                                <input value="<?php echo e(old('first')); ?>" type="text" name="first" class="form-control" placeholder="First name">
                            <?php $__errorArgs = ['first'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 mb-4" data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-aos-duration="1500">
                                <input type="text" value="<?php echo e(old('second')); ?>" name="second" class="form-control" placeholder="Second name">
                            <?php $__errorArgs = ['second'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 mb-4" data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-aos-duration="2000">
                                <input type="text" value="<?php echo e(old('email')); ?>" name="email" class="form-control" placeholder="Email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 mb-4" data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-aos-duration="2500">
                                <input type="text" value="<?php echo e(old('phone')); ?>" name="phone" class="form-control" placeholder="Phone number">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12 mb-4" data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-aos-duration="3000">
                                <textarea name="message" value="<?php echo e(old('message')); ?>" id="" rows="5" class="form-control"></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12" data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-aos-duration="3000">
                                <button type="submit" class="btn btn-primary btn-shadow">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-4">
                    <h5 class="mt-100" data-aos="fade-down" data-aos-duration="500">Address</h5>
                    <p data-aos="fade-down" data-aos-duration="1000">542, 8 no. Street, New York, MAC 5245, Westhill</p>
                    <br>
                    <h5 data-aos="fade-down" data-aos-duration="1500">Email</h5>
                    <p data-aos="fade-down" data-aos-duration="2000">teamorange007@gmail.com</p>
                    <br>
                    <h5 data-aos="fade-down" data-aos-duration="2500">Phone</h5>
                    <p data-aos="fade-down" data-aos-duration="3000">9895 72 80 07</p>
                </div>
            </div>
        </div>
      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sugeesh/Desktop/digital marketing/teamorange/resources/views/web/contact.blade.php ENDPATH**/ ?>