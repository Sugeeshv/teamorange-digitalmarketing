
<aside class="main-sidebar">
				<!-- sidebar-->
				<section class="sidebar position-relative"> 
					<div class="multinav">
					  <div class="multinav-scroll" style="height: 100%;">   
						  <!-- sidebar menu-->
						  <ul class="sidebar-menu" data-widget="tree">  
							<li class="header">Dashboard & Apps</li>
							<li class="">
							  <a href="{{url('/home')}}">
								<i class="icon-Layout-4-blocks"><span class="path1"></span><span class="path2"></span></i>
								<span>Dashboard</span>
								<span class="pull-right-container">
								  <i class="fa fa-angle-right pull-right"></i>
								</span>
							  </a>
							</li> 
							<li class="">
							  <a href="{{url('/services-view')}}">
								<i class="icon-Layout-4-blocks"><span class="path1"></span><span class="path2"></span></i>
								<span>Services</span>
							  </a>
							</li>    
						  </ul>
					  </div>
					</div>
				</section>
				<div class="sidebar-footer">
					<a href="javascript:void(0)" class="link" data-bs-toggle="tooltip" title="Settings"><span class="icon-Settings-2"></span></a>
					<a href="mailbox.html" class="link" data-bs-toggle="tooltip" title="Email"><span class="icon-Mail"></span></a>
					<a href="javascript:void(0)" class="link" data-bs-toggle="tooltip" title="Logout"><span class="icon-Lock-overturning"><span class="path1"></span><span class="path2"></span></span></a>
				</div>
		  	</aside>